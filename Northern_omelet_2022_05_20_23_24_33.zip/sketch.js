//sons do jogo
let raquetada;
let ponto;
let trilha;

//Pontuações
let meusPontos = 0;
let pontosDoOponente = 0;
let pt = true;

//variáveis da bolinha
let xBolinha = 300;
let yBolinha = 200;
let diametro = 15;
let raio = diametro / 2;

//velocidade da bolinha
let velocidadeXBolinha = 10;
let velocidadeYBolinha = 10;

//variáveis da raquete
let xRaquete = 5;
let yRaquete = 150;
let raqueteComprimento = 10;
let raqueteAltura = 90;

//variáveis da raquete adversária
let xRaqueteOponente = 585;
let yRaqueteOponente = 150;
let raqueteOponenteComprimento = 10;
let raqueteOponenteAltura = 90;

function setup() {
  createCanvas(600, 400);
}

function preload() {
  trilha = loadSound("trilha.mp3");
  ponto = loadSound("ponto.mp3");
  raquetada = loadSound("raquetada.mp3");
}

function setup() {
  createCanvas(600, 400);
  trilha.loop();
}

function draw() {
  background(0);
  rect(295, 0, 10, 400);
  mostraBolinha();
  movimentaBolinha();
  verificaColisaoBorda();
  mostraRaquete();
  movimentaRaquete();
  verificaColisaoRaquete();
  incluiPlacar();
  marcaPonto();
}

function mostraBolinha() {
  circle(xBolinha, yBolinha, diametro);
}

function movimentaBolinha() {
  xBolinha += velocidadeXBolinha;
  yBolinha += velocidadeYBolinha;
}

function verificaColisaoBorda() {
  if (xBolinha + raio > width || xBolinha - raio < 0) {
    velocidadeXBolinha *= -1;
  }
  if (yBolinha + raio > height || yBolinha - raio < 0) {
    velocidadeYBolinha *= -1;
  }
}

function mostraRaquete() {
  rect(xRaquete, yRaquete, raqueteComprimento, raqueteAltura);

  rect(
    xRaqueteOponente,
    yRaqueteOponente,
    raqueteOponenteComprimento,
    raqueteOponenteAltura
  );
}

function movimentaRaquete() {
  if (keyIsDown(UP_ARROW) && yRaqueteOponente > 0) {
    yRaqueteOponente -= 10;
  } else if (keyIsDown(DOWN_ARROW) && yRaqueteOponente < 310) {
    yRaqueteOponente += 10;
  }

  if (keyIsDown(87) && yRaquete > 0) {
    yRaquete -= 10;
  } else if (keyIsDown(83) && yRaquete < 310) {
    yRaquete += 10;
  }
}

function verificaColisaoRaquete() {
  if (
    xBolinha - raio < xRaquete + raqueteComprimento &&
    yBolinha < yRaquete + raqueteAltura &&
    yBolinha + raio > yRaquete
  ) {
    velocidadeXBolinha *= -1;
    raquetada.play();
  } else if (
    xBolinha + raio * 2 > xRaqueteOponente + raqueteOponenteComprimento &&
    yBolinha < yRaqueteOponente + raqueteOponenteAltura &&
    yBolinha + raio > yRaqueteOponente
  ) {
    velocidadeXBolinha *= -1;
    raquetada.play();
  }
}

function incluiPlacar() {
  stroke(255);
  textAlign(CENTER);
  textSize(36);
  fill(color(255, 140, 0));
  rect(147, 6, 45, 35);
  fill(255);
  text(meusPontos, 170, 36);
  fill(color(255, 140, 0));
  rect(447, 6, 45, 35);
  fill(255);
  text(pontosDoOponente, 470, 36);
}

function dpsPonto() {
  if (pt == true) {
    velocidadeXBolinha = 10;
    velocidadeYBolinha = 10;
  } else {
    velocidadeXBolinha = -10;
    velocidadeYBolinha = -10;
  }
}

function marcaPonto() {
  if (xBolinha > 590) {
    meusPontos += 1;
    xBolinha = 300;
    yBolinha = 200;
    ponto.play();
    velocidadeXBolinha = 0;
    velocidadeYBolinha = 0;
    pt = true;
    setTimeout(dpsPonto, 200);
  }
  if (xBolinha < 10) {
    pontosDoOponente += 1;
    xBolinha = 300;
    yBolinha = 200;
    ponto.play();
    velocidadeXBolinha = 0;
    velocidadeYBolinha = 0;
    pt = false;
    setTimeout(dpsPonto, 200);
  }
}
